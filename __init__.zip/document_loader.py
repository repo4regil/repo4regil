"""
document_loader.py
------------------
Handles loading a Word document (.docm / .docx) from raw uploaded bytes
into a ``python-docx`` Document object.

Design notes
~~~~~~~~~~~~
* python-docx cannot open ``.docm`` files by extension, but the underlying
  OOXML format (ZIP) is identical.  We rename the temp file to ``.docx``
  before opening so python-docx is happy.
* Temp files are placed in ``tmp/`` and cleaned up by calling
  ``clear_document()``.
"""

import logging
import os
import shutil
from typing import Optional, Tuple

from docx import Document
from docx.oxml.ns import qn

from config import ALLOWED_EXTENSIONS, TMP_DIR


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_document(
    file_bytes: bytes,
    original_filename: str,
    logger: logging.Logger,
) -> Tuple[Optional[object], Optional[str], Optional[str]]:
    """
    Save ``file_bytes`` to a temp file and open it as a python-docx Document.

    Parameters
    ----------
    file_bytes : bytes
        Raw bytes from ``st.file_uploader``.
    original_filename : str
        The user-supplied filename (used for extension validation & temp naming).
    logger : logging.Logger
        Session logger.

    Returns
    -------
    tuple of (Document | None, tmp_path | None, error_message | None)
        On success: (doc, tmp_path, None)
        On failure: (None, None, error_message)
    """
    logger.info("Loading document: %s (%d bytes)", original_filename, len(file_bytes))

    # ------------------------------------------------------------------
    # 1. Validate extension
    # ------------------------------------------------------------------
    ext = os.path.splitext(original_filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        msg = (
            f"Unsupported file type '{ext}'. "
            f"Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )
        logger.warning(msg)
        return None, None, msg

    # ------------------------------------------------------------------
    # 2. Write to temp directory (always as .docx so python-docx can read it)
    # ------------------------------------------------------------------
    os.makedirs(TMP_DIR, exist_ok=True)
    tmp_filename = os.path.splitext(original_filename)[0] + "_tmp.docx"
    tmp_path = os.path.join(TMP_DIR, tmp_filename)

    try:
        with open(tmp_path, "wb") as fh:
            fh.write(file_bytes)
        logger.debug("Temp file written: %s", tmp_path)
    except OSError as exc:
        msg = f"Could not write temp file: {exc}"
        logger.error(msg)
        return None, None, msg

    # ------------------------------------------------------------------
    # 3. Open with python-docx
    # ------------------------------------------------------------------
    try:
        doc = Document(tmp_path)
        logger.info("Document opened successfully.")
        return doc, tmp_path, None
    except Exception as exc:  # noqa: BLE001
        msg = f"Failed to parse document: {exc}"
        logger.error(msg)
        # Clean up the temp file on parse failure
        _delete_file(tmp_path, logger)
        return None, None, msg


def clear_document(tmp_path: Optional[str], logger: logging.Logger) -> None:
    """
    Delete the temporary copy of the uploaded document from disk.

    Parameters
    ----------
    tmp_path : str or None
        Path returned by :func:`load_document`.  If None, this is a no-op.
    logger : logging.Logger
        Session logger.
    """
    if tmp_path:
        _delete_file(tmp_path, logger)
        logger.info("Temporary document removed from memory/disk.")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _delete_file(path: str, logger: logging.Logger) -> None:
    """Remove a single file, logging any errors."""
    try:
        if os.path.exists(path):
            os.remove(path)
            logger.debug("Deleted temp file: %s", path)
    except OSError as exc:
        logger.warning("Could not delete temp file %s: %s", path, exc)
