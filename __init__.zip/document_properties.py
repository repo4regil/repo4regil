"""
document_properties.py
-----------------------
Extracts metadata and structural statistics from a python-docx Document.

The function returns a :class:`~models.DocumentProperties` instance which
is then displayed in the UI and logged for audit purposes.
"""

import logging
from typing import Optional

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT

from models import DocumentProperties


def extract_properties(
    doc: Document,
    logger: logging.Logger,
) -> DocumentProperties:
    """
    Extract core properties and structural stats from *doc*.

    Parameters
    ----------
    doc : docx.Document
        An already-opened python-docx Document object.
    logger : logging.Logger
        Session logger.

    Returns
    -------
    DocumentProperties
        Populated dataclass; missing fields are ``None``.
    """
    logger.info("Extracting document properties …")
    props = doc.core_properties

    # ------------------------------------------------------------------
    # Helper: safely convert datetime to ISO string
    # ------------------------------------------------------------------
    def _dt(value) -> Optional[str]:
        try:
            return value.isoformat() if value else None
        except Exception:
            return None

    # ------------------------------------------------------------------
    # Structural counts
    # ------------------------------------------------------------------
    section_count = len(doc.sections)
    word_count    = _count_words(doc)
    page_count    = _estimate_pages(doc)

    dp = DocumentProperties(
        title             = props.title            or None,
        subject           = props.subject          or None,
        author            = props.author           or None,
        last_modified_by  = props.last_modified_by or None,
        created           = _dt(props.created),
        modified          = _dt(props.modified),
        revision          = str(props.revision) if props.revision else None,
        keywords          = props.keywords         or None,
        description       = props.description      or None,
        page_count        = page_count,
        word_count        = word_count,
        section_count     = section_count,
    )

    logger.info(
        "Properties extracted – title=%r, author=%r, pages≈%s, words≈%s",
        dp.title, dp.author, dp.page_count, dp.word_count,
    )
    return dp


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _count_words(doc: Document) -> int:
    """
    Count words across all paragraphs in the document body.

    This is a simple whitespace-split count and does not match Word's
    built-in word count exactly, but it provides a useful approximation.
    """
    total = 0
    for para in doc.paragraphs:
        total += len(para.text.split())
    return total


def _estimate_pages(doc: Document) -> int:
    """
    Estimate the number of pages.

    python-docx does not expose rendered page count (that requires Word
    to actually render the document).  We approximate by counting explicit
    page-break markers and manual section breaks, then add 1 for the
    initial page.

    For documents with lots of dense content the real page count may be
    higher; this is flagged in the UI as an estimate.
    """
    page_breaks = 0
    for para in doc.paragraphs:
        for run in para.runs:
            if run._r.xml.find("w:lastRenderedPageBreak") != -1:
                page_breaks += 1
            if run._r.xml.find('w:br w:type="page"') != -1:
                page_breaks += 1
        # Check paragraph-level page breaks via XML
        if '<w:pageBreakBefore/>' in para._p.xml:
            page_breaks += 1

    # Each section (except the first) starts on a new page in most templates
    section_breaks = max(0, len(doc.sections) - 1)

    return 1 + page_breaks + section_breaks
